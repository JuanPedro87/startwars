package com.example.start.wars;

import org.springframework.context.annotation.Configuration;

/**
 * Created by jpcs1 on 30/06/17.
 * esta clase sustituye a la configuracion de los XML
 */
@Configuration
//@EnableJpaAuditing
public class StartWarsConfiguration {
}
