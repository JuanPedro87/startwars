package com.example.start.wars.repository;

import com.example.start.wars.model.Film;

/**
 * Created by jpcs1 on 30/06/17.
 */
public interface CustomFilmRepository {
   // void logFilm(Film film);
}
