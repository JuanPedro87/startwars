package com.example.start.wars.repository;

import com.example.start.wars.model.Film;
import lombok.extern.slf4j.Slf4j;


/**
 * Created by jpcs1 on 30/06/17.
 */
@Slf4j
//@ConfigurationProperties("taller.spring.ua")
public class CustomFilmRepositoryImpl implements CustomFilmRepository{
    //@Getter @Setter
    //private List<String> aulas;
    //@Override
    //public void logFilm(Film film) {log.info(film.toString());}

}
